# gear.mng

Meris Besic

## User Interface

Die Hauptfunktion von gear.mng ist, einer Film- oder Foto-Firma bei der Organisation Ihres Equipments zu helfen, da bei vielen verschiedenen Equipmentstücken schnell Verwirrung auftreten kann. Damit das nicht so einfach passiert kann man sich bei gear.mng anmelden um dann einen QR- oder Barcode auf der Kamera oder dem Objektiv zu scannen. Anschließend kann der Benutzer eintragen von wann bis wann er dieses Equipment braucht. Dies wird in einen Kalender eingetragen damit jeder weiß wann etwas nicht mehr verfügbar ist.



## Aus der Sicht des Entwicklers

Um die verschiedenen Teile zu speichern, wird eine Datenbank benötigt. Außerdem müssen noch Benutzerdaten und die Zeit des Verleihs gespeichert werden. Des weiteren wird eine Art von Verifizierung gebraucht werden damit nicht jemand unter einem anderen Namen Equipment ausborgen zu können. 